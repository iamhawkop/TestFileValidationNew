package steps;

import io.cucumber.java.en.Then;
import utils.SikuliUtils;
import utils.SikuliUtilsAdaptive;
import utils.SikuliUtilsResolutionFree;

public class SaveAsSteps {

    @Then("I save PDF using basic Sikuli")
    public void saveWithBasicSikuli() throws Exception {
        String downloadPath = System.getProperty("user.dir") + "/target/downloads/myDownloadedFile.pdf";
        SikuliUtils.click("filename_box", 10);
        SikuliUtils.type(downloadPath);
        SikuliUtils.click("save_button", 10);
    }

    @Then("I save PDF using adaptive Sikuli")
    public void saveWithAdaptiveSikuli() throws Exception {
        String downloadPath = System.getProperty("user.dir") + "/target/downloads/myDownloadedFile.pdf";
        SikuliUtilsAdaptive.clearAndTypeNextToLabel("file_name_label", downloadPath, 100, 180, 10);
        SikuliUtils.click("save_button", 10);
    }

    @Then("I save PDF using resolution free Sikuli")
    public void saveWithResolutionFreeSikuli() throws Exception {
        String downloadPath = System.getProperty("user.dir") + "/target/downloads/myDownloadedFile.pdf";
        SikuliUtilsResolutionFree.clearAndTypeInBoxRightOfLabel("file_name_label", downloadPath);
        SikuliUtils.click("save_button", 10);
    }
}
