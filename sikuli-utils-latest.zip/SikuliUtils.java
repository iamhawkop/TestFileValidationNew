package utils;

import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;

public class SikuliUtils {
    private static final Screen screen = new Screen();

    public static void click(String imageName, int waitTime) throws Exception {
        String baseDir = System.getProperty("user.dir") + "/src/test/resources/sikuli_images/";
        Pattern pattern = new Pattern(baseDir + imageName + ".png");
        screen.wait(pattern, waitTime);
        screen.click(pattern);
    }

    public static void type(String text) {
        screen.type(text);
    }

    public static boolean exists(String imageName, int waitTime) throws Exception {
        String baseDir = System.getProperty("user.dir") + "/src/test/resources/sikuli_images/";
        Pattern pattern = new Pattern(baseDir + imageName + ".png");
        return screen.exists(pattern, waitTime) != null;
    }
}
