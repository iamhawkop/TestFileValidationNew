package utils;

import org.sikuli.script.Key;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;

public class SikuliUtilsAdaptive {
    private static final Screen screen = new Screen();

    public static void clearAndTypeNextToLabel(String labelImage, String text,
                                               int startOffset, int maxOffset, int step) throws Exception {

        String baseDir = System.getProperty("user.dir") + "/src/test/resources/sikuli_images/";
        Pattern label = new Pattern(baseDir + labelImage + ".png").similar(0.9f);

        screen.wait(label, 10);
        boolean typed = false;

        for (int offset = startOffset; offset <= maxOffset; offset += step) {
            try {
                screen.click(label.targetOffset(offset, 0));
                screen.type("a", Key.CTRL);
                screen.type(Key.BACKSPACE);
                screen.type("TEST");
                Thread.sleep(200);
                screen.type("a", Key.CTRL);
                screen.type(Key.BACKSPACE);
                screen.type(text);
                typed = true;
                System.out.println("✅ Typed using offset: " + offset);
                break;
            } catch (Exception e) {
                System.out.println("⚠️ Failed at offset " + offset + ", trying next...");
            }
        }

        if (!typed) {
            throw new Exception("❌ Could not type in textbox near " + labelImage);
        }
    }
}
