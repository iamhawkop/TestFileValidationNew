package utils;

import org.sikuli.script.*;

public class SikuliUtilsResolutionFree {
    private static final Screen screen = new Screen();

    public static void clearAndTypeInBoxRightOfLabel(String labelImage, String text) throws Exception {
        String baseDir = System.getProperty("user.dir") + "/src/test/resources/sikuli_images/";
        Pattern label = new Pattern(baseDir + labelImage + ".png").similar(0.9f);

        Match match = screen.wait(label, 10);
        int regionWidth = 300; // enough to cover textbox
        int regionHeight = match.getH();
        Region textBoxRegion = new Region(match.getX() + match.getW(), match.getY(), regionWidth, regionHeight);

        textBoxRegion.click();
        screen.type("a", Key.CTRL);
        screen.type(Key.BACKSPACE);
        screen.type(text);
        System.out.println("✅ Typed into textbox using resolution-free approach.");
    }
}
