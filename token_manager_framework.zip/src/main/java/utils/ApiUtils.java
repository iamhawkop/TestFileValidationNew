package utils;

import org.json.JSONObject;
import java.net.http.*;
import java.net.URI;
import java.nio.charset.StandardCharsets;

public class ApiUtils {

    public static String generateBearerToken() {
        try {
            HttpClient client = HttpClient.newHttpClient();
            String requestBody = new JSONObject()
                    .put("username", "your_username")
                    .put("password", "your_password")
                    .toString();

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create("https://your-api.com/token"))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(requestBody, StandardCharsets.UTF_8))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            JSONObject jsonResponse = new JSONObject(response.body());

            return jsonResponse.getString("access_token");
        } catch (Exception e) {
            throw new RuntimeException("Failed to generate bearer token: " + e.getMessage(), e);
        }
    }
}
