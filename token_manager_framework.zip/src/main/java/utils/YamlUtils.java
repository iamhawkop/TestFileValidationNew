package utils;

import org.yaml.snakeyaml.DumperOptions;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.SafeConstructor;

import java.io.*;
import java.util.Map;

public class YamlUtils {

    @SuppressWarnings("unchecked")
    public static Map<String, Object> readYamlFile(String filePath) {
        try (InputStream input = new FileInputStream(filePath)) {
            Yaml yaml = new Yaml(new SafeConstructor());
            return yaml.load(input);
        } catch (IOException e) {
            throw new RuntimeException("Failed to read YAML file: " + e.getMessage(), e);
        }
    }

    public static void writeYamlFile(String filePath, Map<String, Object> data) {
        try (Writer writer = new FileWriter(filePath)) {
            DumperOptions options = new DumperOptions();
            options.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK);
            Yaml yaml = new Yaml(options);
            yaml.dump(data, writer);
        } catch (IOException e) {
            throw new RuntimeException("Failed to write YAML file: " + e.getMessage(), e);
        }
    }
}
