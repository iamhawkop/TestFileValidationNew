package steps;

import io.cucumber.java.en.Given;
import utils.ApiUtils;
import utils.YamlUtils;

import java.io.File;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

public class TokenSteps {

    private static final String YAML_PATH = "src/test/resources/token_store.yaml";

    @Given("user generates bearer token if expired")
    public void userGeneratesBearerTokenIfExpired() {
        File file = new File(YAML_PATH);

        Map<String, Object> tokenData = file.exists()
                ? YamlUtils.readYamlFile(YAML_PATH)
                : new HashMap<>();

        String token = (String) tokenData.get("token");
        String tokenTime = (String) tokenData.get("token_time");

        boolean generateNewToken = true;

        if (token != null && tokenTime != null) {
            LocalDateTime savedTime = LocalDateTime.parse(tokenTime);
            Duration diff = Duration.between(savedTime, LocalDateTime.now());
            if (diff.toMinutes() < 5) {
                generateNewToken = false;
                System.out.println("✅ Using existing token (not expired)");
            }
        }

        if (generateNewToken) {
            System.out.println("🔄 Generating new token...");
            token = ApiUtils.generateBearerToken();

            tokenData.put("token", token);
            tokenData.put("token_time", LocalDateTime.now().toString());

            YamlUtils.writeYamlFile(YAML_PATH, tokenData);
            System.out.println("✅ New token saved in YAML file");
        }

        System.setProperty("bearer.token", token);
    }
}
