package com.example;

import java.io.File;

public class FileUtilsHelper {
    public static File waitForFile(String dirPath, String fileName, int timeoutSeconds) {
        File dir = new File(dirPath);
        File file = new File(dir, fileName);

        int counter = 0;
        while (counter < timeoutSeconds) {
            if (file.exists()) {
                return file;
            }
            try { Thread.sleep(1000); } catch (InterruptedException ignored) {}
            counter++;
        }
        throw new RuntimeException("File not downloaded: " + fileName);
    }
}
