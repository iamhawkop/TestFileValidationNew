package com.example;

import io.cucumber.java.en.Then;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.io.File;

public class DownloadSteps {
    WebDriver driver;
    String downloadDir = System.getProperty("user.dir") + "/target/downloads";

    @Then("I download {string} file and validate content {string}")
    public void downloadFile(String fileName, String expectedText) throws Exception {
        // Click download button
        driver.findElement(By.xpath("//button[@id='download']")).click();

        // Wait for download
        File file = FileUtilsHelper.waitForFile(downloadDir, fileName, 30);

        // Validate based on extension
        String actualText = "";
        if (fileName.endsWith(".pdf")) {
            actualText = PdfValidator.readPdf(file);
        } else if (fileName.endsWith(".xlsx")) {
            actualText = ExcelValidator.readFirstCell(file);
        } else if (fileName.endsWith(".csv")) {
            actualText = CsvValidator.readFirstLine(file);
        }

        if (!actualText.contains(expectedText)) {
            throw new AssertionError("Expected text not found in file. Found: " + actualText);
        }

        // Screenshot
        ReportHelper.attachScreenshot(driver, "Download Screenshot");

        // Attach file
        ReportHelper.attachFile(file, "Downloaded File");
    }
}
