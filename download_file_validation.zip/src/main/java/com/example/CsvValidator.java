package com.example;

import java.io.BufferedReader;
import java.io.FileReader;

public class CsvValidator {
    public static String readFirstLine(File file) throws Exception {
        BufferedReader br = new BufferedReader(new FileReader(file));
        String line = br.readLine();
        br.close();
        return line;
    }
}
