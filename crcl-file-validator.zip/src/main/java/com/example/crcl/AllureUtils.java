package com.example.crcl;

import io.qameta.allure.Allure;
import java.io.File;
import java.io.FileInputStream;

public class AllureUtils {
    public static void attachFile(File file) throws Exception {
        try (FileInputStream fis = new FileInputStream(file)) {
            Allure.addAttachment(file.getName(), fis);
        }
    }
}
