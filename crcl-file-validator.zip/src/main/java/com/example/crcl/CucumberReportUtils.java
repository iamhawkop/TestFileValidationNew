package com.example.crcl;

import io.cucumber.java.Scenario;
import java.io.File;
import java.nio.file.Files;

public class CucumberReportUtils {
    public static void attachFileToScenario(Scenario scenario, File file) throws Exception {
        byte[] fileContent = Files.readAllBytes(file.toPath());
        scenario.attach(fileContent, "text/plain", file.getName());
    }
}
