package com.example.crcl;

import java.io.File;
import java.nio.file.Files;
import java.nio.charset.StandardCharsets;

public class CRCLValidator {
    public static void validateFileContent(File file, String expectedText) throws Exception {
        String content = new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8);
        if (!content.contains(expectedText)) {
            throw new AssertionError("Expected text not found: " + expectedText);
        }
        System.out.println("Validation passed: " + expectedText);
    }
}
