package com.example.crcl;

import org.sikuli.script.Screen;
import org.sikuli.script.Key;

public class SikuliUtils {
    public static void highlightAndScreenshot(String keyword, String screenshotPath) throws Exception {
        Screen screen = new Screen();
        // Open Find dialog (Ctrl+F)
        screen.type("f", Key.CTRL);
        Thread.sleep(1000);
        // Type keyword
        screen.type(keyword);
        Thread.sleep(500);
        // Press Enter to highlight
        screen.type(Key.ENTER);
        Thread.sleep(1000);
        // Take screenshot
        screen.capture().save(screenshotPath, "highlighted.png");
        System.out.println("Screenshot saved at: " + screenshotPath + "/highlighted.png");
    }
}
