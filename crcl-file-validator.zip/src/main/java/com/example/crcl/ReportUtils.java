package com.example.crcl;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import java.io.File;

public class ReportUtils {
    private static ExtentReports extent;
    private static ExtentTest test;

    public static void initReport(String reportPath) {
        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(reportPath);
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
        test = extent.createTest("CRCL File Validation Test");
    }

    public static void logFileAttachment(File file) {
        test.info("Attached CRCL file: <a href='" + file.getAbsolutePath() + "'>Open CRCL</a>");
    }

    public static void flush() {
        extent.flush();
    }
}
