package com.example.crcl;

import java.io.File;

public class CRCLFileTest {
    public static void main(String[] args) throws Exception {
        String folderPath = "C:/path/to/folder";
        String expectedText = "ContractID";
        String screenshotPath = "C:/path/to";

        // Get latest CRCL file
        File latestFile = FileUtils.getLatestCRCLFile(folderPath);
        System.out.println("Latest File: " + latestFile.getName());

        // Validate file content
        CRCLValidator.validateFileContent(latestFile, expectedText);

        // Open file in Notepad
        Runtime.getRuntime().exec("notepad " + latestFile.getAbsolutePath());
        Thread.sleep(3000);

        // Highlight and screenshot using Sikuli
        SikuliUtils.highlightAndScreenshot(expectedText, screenshotPath);

        // Attach to Extent report
        ReportUtils.initReport("C:/path/to/report.html");
        ReportUtils.logFileAttachment(latestFile);
        ReportUtils.flush();
    }
}
