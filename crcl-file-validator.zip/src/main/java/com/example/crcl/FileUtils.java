package com.example.crcl;

import java.io.File;
import java.util.Arrays;
import java.util.Comparator;

public class FileUtils {
    public static File getLatestCRCLFile(String folderPath) {
        File dir = new File(folderPath);
        File[] files = dir.listFiles((d, name) -> name.toLowerCase().endsWith(".crcl"));

        if (files == null || files.length == 0) {
            throw new RuntimeException("No .CRCL files found in directory: " + folderPath);
        }

        return Arrays.stream(files)
                .max(Comparator.comparingLong(File::lastModified))
                .orElseThrow(() -> new RuntimeException("No latest .CRCL file found"));
    }
}
