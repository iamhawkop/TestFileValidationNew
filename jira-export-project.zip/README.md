# Jira Exporter - Spring Boot

This project exports Jira Test issues (Issue Key, FeatureTeam, Epic Link and Epic Summary) to an Excel file.

## Fields configured
- FeatureTeam: customfield_11400
- Epic Link: customfield_10001

## Build & Run

1. Copy `src/main/resources/application.properties.example` to `src/main/resources/application.properties` and fill Jira credentials.
2. Build:
   ```
   mvn clean package
   ```
3. Run:
   ```
   java -jar target/jira-export-1.0.0.jar
   ```

## Usage

Trigger export (download response):
```
GET http://localhost:8080/api/jira/export?project=ABC&label=regression
```

This returns an Excel file (`JiraExport.xlsx`) containing:
| Issue Key | FeatureTeam | Epic Key | Epic Summary |

Notes:
- The exporter paginates using maxResults=100 and will iterate until all issues are fetched.
- Epic summary is retrieved by calling the issue API for each epic key.
- Ensure the provided custom field IDs match your Jira instance.

