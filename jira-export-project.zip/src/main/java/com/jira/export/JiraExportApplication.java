package com.jira.export;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JiraExportApplication {
    public static void main(String[] args) {
        SpringApplication.run(JiraExportApplication.class, args);
    }
}
