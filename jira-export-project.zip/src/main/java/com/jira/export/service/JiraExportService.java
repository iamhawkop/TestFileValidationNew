package com.jira.export.service;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.*;

import java.io.FileOutputStream;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Service
public class JiraExportService {

    @Value("${jira.base.url}")
    private String jiraBaseUrl;

    @Value("${jira.username}")
    private String jiraUsername;

    @Value("${jira.api.token}")
    private String jiraApiToken;

    // Provided field IDs
    private final String FEATURE_TEAM_FIELD = "customfield_11400";
    private final String EPIC_LINK_FIELD = "customfield_10001";

    private final HttpClient httpClient = HttpClient.newHttpClient();

    /**
     * Export issues to Excel. Returns absolute path to generated file.
     */
    public String exportIssuesToExcel(String jql) {
        int startAt = 0;
        int maxResults = 100;
        boolean isLast = false;

        List<Map<String, String>> rows = new ArrayList<>();

        try {
            String encodedJql = URLEncoder.encode(jql, StandardCharsets.UTF_8);

            while (!isLast) {
                String url = String.format("%s/rest/api/3/search?jql=%s&fields=summary,%s,%s&maxResults=%d&startAt=%d",
                        jiraBaseUrl, encodedJql, FEATURE_TEAM_FIELD, EPIC_LINK_FIELD, maxResults, startAt);

                HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(url))
                        .header("Authorization", "Basic " + encodeCreds())
                        .header("Accept", "application/json")
                        .GET()
                        .build();

                HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

                JSONObject json = new JSONObject(response.body());
                JSONArray issues = json.getJSONArray("issues");
                int total = json.getInt("total");

                for (int i = 0; i < issues.length(); i++) {
                    JSONObject issue = issues.getJSONObject(i);
                    String key = issue.getString("key");
                    JSONObject fields = issue.getJSONObject("fields");

                    // FeatureTeam extraction
                    String featureTeam = "";
                    if (!fields.isNull(FEATURE_TEAM_FIELD)) {
                        Object obj = fields.get(FEATURE_TEAM_FIELD);
                        if (obj instanceof JSONObject) {
                            featureTeam = ((JSONObject) obj).optString("value", "");
                        } else if (obj instanceof String) {
                            featureTeam = (String) obj;
                        } else if (obj instanceof JSONArray) {
                            // multi-select
                            JSONArray arr = (JSONArray) obj;
                            List<String> vals = new ArrayList<>();
                            for (int k = 0; k < arr.length(); k++) {
                                JSONObject it = arr.getJSONObject(k);
                                vals.add(it.optString("value", it.toString()));
                            }
                            featureTeam = String.join(",", vals);
                        }
                    }

                    // Epic Link extraction (epic key)
                    String epicKey = "";
                    String epicSummary = "";
                    if (!fields.isNull(EPIC_LINK_FIELD)) {
                        Object e = fields.get(EPIC_LINK_FIELD);
                        // Epic Link is usually a String key like ABC-12
                        if (e instanceof String) {
                            epicKey = (String) e;
                            epicSummary = fetchEpicSummary(epicKey);
                        } else if (e instanceof JSONObject) {
                            // sometimes stored differently
                            epicKey = ((JSONObject) e).optString("key", "");
                            if (!epicKey.isEmpty()) {
                                epicSummary = fetchEpicSummary(epicKey);
                            }
                        }
                    }

                    Map<String, String> row = new HashMap<>();
                    row.put("issueKey", key);
                    row.put("featureTeam", featureTeam);
                    row.put("epicKey", epicKey);
                    row.put("epicSummary", epicSummary);
                    rows.add(row);
                }

                startAt += maxResults;
                if (startAt >= total) {
                    isLast = true;
                }
            }

            String outputPath = "JiraExport.xlsx";
            writeExcel(rows, outputPath);
            // move to absolute path inside working dir
            String abs = System.getProperty("user.dir") + "/" + outputPath;
            return abs;

        } catch (Exception e) {
            throw new RuntimeException("Error exporting issues to Excel: " + e.getMessage(), e);
        }
    }

    private String fetchEpicSummary(String epicKey) {
        try {
            String url = String.format("%s/rest/api/3/issue/%s?fields=summary", jiraBaseUrl, epicKey);
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Authorization", "Basic " + encodeCreds())
                    .header("Accept", "application/json")
                    .GET()
                    .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            JSONObject json = new JSONObject(response.body());
            return json.getJSONObject("fields").optString("summary", "");
        } catch (Exception ex) {
            return "";
        }
    }

    private void writeExcel(List<Map<String, String>> rows, String path) throws Exception {
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Jira Issues");

            int rowNum = 0;
            Row header = sheet.createRow(rowNum++);
            header.createCell(0).setCellValue("Issue Key");
            header.createCell(1).setCellValue("FeatureTeam");
            header.createCell(2).setCellValue("Epic Key");
            header.createCell(3).setCellValue("Epic Summary");

            for (Map<String, String> r : rows) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(r.getOrDefault("issueKey", ""));
                row.createCell(1).setCellValue(r.getOrDefault("featureTeam", ""));
                row.createCell(2).setCellValue(r.getOrDefault("epicKey", ""));
                row.createCell(3).setCellValue(r.getOrDefault("epicSummary", ""));
            }

            try (FileOutputStream fos = new FileOutputStream(path)) {
                workbook.write(fos);
            }
        }
    }

    private String encodeCreds() {
        String creds = jiraUsername + ":" + jiraApiToken;
        return Base64.getEncoder().encodeToString(creds.getBytes());
    }
}
