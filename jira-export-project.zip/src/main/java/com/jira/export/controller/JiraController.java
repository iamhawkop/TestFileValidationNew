package com.jira.export.controller;

import com.jira.export.service.JiraExportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.nio.file.Files;

@RestController
@RequestMapping("/api/jira")
public class JiraController {

    @Autowired
    private JiraExportService jiraExportService;

    /**
     * Trigger export. The endpoint will run the export and return the generated Excel file as attachment.
     * Example:
     * GET /api/jira/export?project=ABC&label=regression
     */
    @GetMapping("/export")
    public ResponseEntity<byte[]> export(@RequestParam String project,
                                         @RequestParam String label) throws Exception {

        String jql = String.format("project = %s AND issuetype = Test AND labels = %s", project, label);

        String outputPath = jiraExportService.exportIssuesToExcel(jql);

        File file = new File(outputPath);
        byte[] content = Files.readAllBytes(file.toPath());

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename="" + file.getName() + """)
                .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .body(content);
    }
}
